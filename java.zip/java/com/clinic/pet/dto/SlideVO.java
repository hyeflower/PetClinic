package com.clinic.pet.dto;

public class SlideVO {
	private int slideno;
	private String pic;
	
	
	
	public int getSlideno() {
		return slideno;
	}

	public void setSlideno(int slideno) {
		this.slideno = slideno;
	}

	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

}
